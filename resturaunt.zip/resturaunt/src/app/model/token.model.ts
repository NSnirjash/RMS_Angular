import { User } from "./user.model";


export class Token {
    // Add the token properties here, e.g.
    id!: number;
    token!: string;
    user!: User;
  
    
  }