export enum Role {
    
    ADMIN,
    USER,
    WAITER
  }