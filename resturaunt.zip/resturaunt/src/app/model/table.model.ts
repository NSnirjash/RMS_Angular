export class TableModel {
    id?: number; 
    tableNumber!: string;
    capacity!: number;
    status!: string;
}