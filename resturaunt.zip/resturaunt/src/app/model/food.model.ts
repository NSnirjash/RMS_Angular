export class FoodModel {
    id!: number;
    name!: string;
    price!: number;
    category!: string;
    available!: boolean;
    image!: string;
  }